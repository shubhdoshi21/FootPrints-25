(self["webpackChunk_N_E"] = self["webpackChunk_N_E"] || []).push([[389],{

/***/ 2597:
/***/ (function(__unused_webpack_module, __unused_webpack_exports, __webpack_require__) {

Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 3185, 23));
;
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 5775));


/***/ }),

/***/ 5775:
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(7437);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2265);
/* __next_internal_client_entry_do_not_use__ default auto */ 

const teamMembers = [
    {
        name: "Ayesha Patel",
        position: "Production Designer",
        image: "/images/ayesha.jpg",
        social: {
            linkedin: "http://www.linkedin.com/in/ayeshapatel07",
            github: "https://github.com/ayesha1209",
            instagram: "https://instagram.com/thein_dan_ma"
        }
    },
    {
        name: "Vrunda Radadiya",
        position: "Product Designer",
        image: "/images/vrunda.jpg",
        social: {
            linkedin: "https://www.linkedin.com/in/vrunda-radadiya-8a1a43257/",
            github: "https://github.com/Vrunda2",
            instagram: "https://instagram.com/ngwe_pu"
        }
    },
    {
        name: "Meghana Vasava",
        position: "Customer Service",
        image: "/images/meghana.jpg",
        social: {
            linkedin: "https://www.linkedin.com/in/meghana-vasava-17242a261/",
            github: "https://github.com/meghanavasava",
            instagram: "https://instagram.com/ok_tal_mg_lay"
        }
    },
    {
        name: "Satchit Bhatt",
        position: "Project Leader",
        image: "/images/satchitt.png",
        social: {
            linkedin: "https://www.linkedin.com/in/satchit-bhatt-9933a1253?utm_source=share&utm_campaign=share_via&utm_content=profile&utm_medium=android_app",
            github: "https://github.com/Satchit2",
            instagram: "https://instagram.com/ma_ma_saung"
        }
    },
    {
        name: "Shubh Doshi",
        position: "Customer Service",
        image: "/images/shubh2.png",
        social: {
            linkedin: "https://www.linkedin.com/in/shubh-doshi-921337256/",
            github: "https://github.com/shubhdoshi21",
            instagram: "https://instagram.com/ok_tal_mg_lay"
        }
    },
    {
        name: "Mann Chopda",
        position: "Customer Service",
        image: "/images/mann.jpg",
        social: {
            linkedin: "https://www.linkedin.com/in/man-chopda-63a012278/",
            github: "https://github.com/mann15",
            instagram: "https://instagram.com/ok_tal_mg_lay"
        }
    },
    {
        name: "Megh Prajapati",
        position: "Customer Service",
        image: "/images/megh2.png",
        social: {
            linkedin: "https://www.linkedin.com/in/megh-prajapati-ab13a82b3?utm_source=share&utm_campaign=share_via&utm_content=profile&utm_medium=ios_app ",
            github: "https://github.com/Meghhhhh",
            instagram: "https://instagram.com/ok_tal_mg_lay"
        }
    }
];
const WebTeam = ()=>{
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        const handlePointerMove = (e)=>{
            const { currentTarget: el, clientX: x, clientY: y } = e;
            const { top: t, left: l, width: w, height: h } = el.getBoundingClientRect();
            el.style.setProperty("--posX", x - l - w / 2);
            el.style.setProperty("--posY", y - t - h / 2);
        };
        document.body.addEventListener("pointermove", handlePointerMove);
        return ()=>{
            document.body.removeEventListener("pointermove", handlePointerMove);
        };
    }, []);
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("section", {
        style: {
            height: "100%",
            minHeight: "100vh",
            width: "100%",
            backgroundImage: "\n                    linear-gradient(115deg, rgb(150 0 0), rgb(100 0 0)),\n                    radial-gradient(90% 100% at calc(50% + var(--posX, 0) * 1px) calc(0% + var(--posY, 0) * 1px), rgb(200 50 50), rgb(100 0 0)),\n                    radial-gradient(100% 100% at calc(80% - var(--posX, 0) * 1px) calc(0% - var(--posY, 0) * 1px), rgb(220 40 40), rgb(120 0 0)),\n                    radial-gradient(150% 210% at calc(100% + var(--posX, 0) * 1px) calc(0% + var(--posY, 0) * 1px), rgb(180 20 20), rgb(100 10 10)),\n                    radial-gradient(100% 100% at calc(100% - var(--posX, 0) * 1px) calc(30% - var(--posY, 0) * 1px), rgb(240 70 70), rgb(150 20 20)),\n                    linear-gradient(60deg, rgb(200 30 30), rgb(150 10 10))",
            backgroundBlendMode: "overlay, overlay, difference, difference, difference, normal",
            overflowX: "hidden"
        },
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            className: "container mx-auto px-6 py-5 max-w-[70%] my-1",
            children: [
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                    className: "text-center mb-10",
                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("h2", {
                        className: "text-4xl font-extrabold text-white",
                        children: "Meet the Website Team"
                    })
                }),
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                    className: "grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8",
                    children: teamMembers.map((member, index)=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "bg-white rounded-lg shadow-lg overflow-hidden hover:scale-105 transform transition duration-300",
                            children: [
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("img", {
                                    src: member.image,
                                    alt: member.name,
                                    className: "w-full h-48 object-cover"
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: "p-6",
                                    children: [
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("h3", {
                                            className: "text-xl font-semibold text-gray-800",
                                            children: member.name
                                        }),
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                            className: "mt-4 flex space-x-3 text-gray-500",
                                            children: [
                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("a", {
                                                    href: member.social.linkedin,
                                                    className: "hover:text-blue-500",
                                                    target: "_blank",
                                                    rel: "noopener noreferrer",
                                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("i", {
                                                        className: "fab fa-linkedin text-2xl"
                                                    })
                                                }),
                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("a", {
                                                    href: member.social.github,
                                                    className: "hover:text-gray-800",
                                                    target: "_blank",
                                                    rel: "noopener noreferrer",
                                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("i", {
                                                        className: "fab fa-github text-2xl"
                                                    })
                                                })
                                            ]
                                        })
                                    ]
                                })
                            ]
                        }, index))
                })
            ]
        })
    });
};
/* harmony default export */ __webpack_exports__["default"] = (WebTeam);


/***/ }),

/***/ 3185:
/***/ (function() {

// extracted by mini-css-extract-plugin

/***/ })

},
/******/ function(__webpack_require__) { // webpackRuntimeModules
/******/ var __webpack_exec__ = function(moduleId) { return __webpack_require__(__webpack_require__.s = moduleId); }
/******/ __webpack_require__.O(0, [152,971,117,744], function() { return __webpack_exec__(2597); });
/******/ var __webpack_exports__ = __webpack_require__.O();
/******/ _N_E = __webpack_exports__;
/******/ }
]);
(self["webpackChunk_N_E"] = self["webpackChunk_N_E"] || []).push([[931],{

/***/ 7729:
/***/ (function(__unused_webpack_module, __unused_webpack_exports, __webpack_require__) {

Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 3212));


/***/ }),

/***/ 3212:
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": function() { return /* binding */ Home; }
});

// EXTERNAL MODULE: ./node_modules/next/dist/compiled/react/jsx-runtime.js
var jsx_runtime = __webpack_require__(7437);
// EXTERNAL MODULE: ./node_modules/next/dist/compiled/react/index.js
var react = __webpack_require__(2265);
// EXTERNAL MODULE: ./node_modules/@next/font/google/target.css?{"path":"src\\components\\Loader.jsx","import":"Press_Start_2P","arguments":[{"subsets":["latin"],"weight":"400"}],"variableName":"pressStart"}
var target_path_src_components_Loader_jsx_import_Press_Start_2P_arguments_subsets_latin_weight_400_variableName_pressStart_ = __webpack_require__(9211);
var target_path_src_components_Loader_jsx_import_Press_Start_2P_arguments_subsets_latin_weight_400_variableName_pressStart_default = /*#__PURE__*/__webpack_require__.n(target_path_src_components_Loader_jsx_import_Press_Start_2P_arguments_subsets_latin_weight_400_variableName_pressStart_);
// EXTERNAL MODULE: ./src/components/Loader.module.css
var Loader_module = __webpack_require__(1112);
var Loader_module_default = /*#__PURE__*/__webpack_require__.n(Loader_module);
;// CONCATENATED MODULE: ./src/components/Loader.jsx




const Loader = ()=>{
    return /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
        className: (Loader_module_default()).loading,
        children: /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
            className: "".concat((Loader_module_default())["loading-text"], " ").concat((target_path_src_components_Loader_jsx_import_Press_Start_2P_arguments_subsets_latin_weight_400_variableName_pressStart_default()).className),
            children: [
                /*#__PURE__*/ (0,jsx_runtime.jsx)("span", {
                    className: (Loader_module_default())["loading-text-words"],
                    children: "F"
                }),
                /*#__PURE__*/ (0,jsx_runtime.jsx)("span", {
                    className: (Loader_module_default())["loading-text-words"],
                    children: "O"
                }),
                /*#__PURE__*/ (0,jsx_runtime.jsx)("span", {
                    className: (Loader_module_default())["loading-text-words"],
                    children: "O"
                }),
                /*#__PURE__*/ (0,jsx_runtime.jsx)("span", {
                    className: (Loader_module_default())["loading-text-words"],
                    children: "T"
                }),
                /*#__PURE__*/ (0,jsx_runtime.jsx)("span", {
                    className: (Loader_module_default())["loading-text-words"],
                    children: "P"
                }),
                /*#__PURE__*/ (0,jsx_runtime.jsx)("span", {
                    className: (Loader_module_default())["loading-text-words"],
                    children: "R"
                }),
                /*#__PURE__*/ (0,jsx_runtime.jsx)("span", {
                    className: (Loader_module_default())["loading-text-words"],
                    children: "I"
                }),
                /*#__PURE__*/ (0,jsx_runtime.jsx)("span", {
                    className: (Loader_module_default())["loading-text-words"],
                    children: "N"
                }),
                /*#__PURE__*/ (0,jsx_runtime.jsx)("span", {
                    className: (Loader_module_default())["loading-text-words"],
                    children: "T"
                }),
                /*#__PURE__*/ (0,jsx_runtime.jsx)("span", {
                    className: (Loader_module_default())["loading-text-words"],
                    children: "S"
                })
            ]
        })
    });
};
/* harmony default export */ var components_Loader = (Loader);

// EXTERNAL MODULE: ./node_modules/@next/font/google/target.css?{"path":"src\\components\\About.jsx","import":"Ranchers","arguments":[{"subsets":["latin"],"weight":"400"}],"variableName":"ranchers"}
var target_path_src_components_About_jsx_import_Ranchers_arguments_subsets_latin_weight_400_variableName_ranchers_ = __webpack_require__(3047);
var target_path_src_components_About_jsx_import_Ranchers_arguments_subsets_latin_weight_400_variableName_ranchers_default = /*#__PURE__*/__webpack_require__.n(target_path_src_components_About_jsx_import_Ranchers_arguments_subsets_latin_weight_400_variableName_ranchers_);
// EXTERNAL MODULE: ./node_modules/framer-motion/dist/es/render/components/motion/proxy.mjs + 223 modules
var proxy = __webpack_require__(6298);
;// CONCATENATED MODULE: ./src/components/About.jsx
/* __next_internal_client_entry_do_not_use__ default auto */ 



const About = ()=>{
    return /*#__PURE__*/ (0,jsx_runtime.jsx)(proxy/* motion */.E.div, {
        initial: {
            opacity: 0,
            y: 50
        },
        animate: {
            opacity: 1,
            y: 0
        },
        transition: {
            duration: 0.8
        },
        className: "about-section text-white py-16 px-8",
        children: /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
            className: "max-w-4xl mx-auto text-center",
            children: [
                /*#__PURE__*/ (0,jsx_runtime.jsx)("h2", {
                    className: "text-4xl font-bold mb-6 ".concat((target_path_src_components_About_jsx_import_Ranchers_arguments_subsets_latin_weight_400_variableName_ranchers_default()).className, " tracking-wide"),
                    children: "About FootPrints"
                }),
                /*#__PURE__*/ (0,jsx_runtime.jsx)("p", {
                    className: "text-lg leading-relaxed text-gray-300",
                    children: "FootPrints is a National Level Technical Fiesta, which was incepted in 2001 by Sir C N Murthy. It has been rising in colossal proportions from a mere paper presentation comprising of 30 participants in FootPrints'01 to FootPrints'24 that comprised of myriad competitions, workshops, and seminars from the most incurred celebrities. FootPrints has strived to nurture and enlighten the engineering minds of the country and have thereby earned the repute of an avant-garde technical fiesta. It comprises of exceptional tech and non-tech events, tantalizing seminars, startling techzibitions, and engaging workshops by virtuosos. It also works towards the upliftment of society under FootPrints Social Responsibility. At FootPrints, we attach a soul, a heart to this grandiose event. Right from the precious little smiles of children, to engraving history in the Guinness and Limca book of world records, FSR has all the benevolence. It has been a thrilling journey of Innovation and Experience which is something beyond imagination."
                })
            ]
        })
    });
};
/* harmony default export */ var components_About = (About);

// EXTERNAL MODULE: ./node_modules/@next/font/google/target.css?{"path":"src\\components\\Navbar.jsx","import":"Ranchers","arguments":[{"subsets":["latin"],"weight":"400"}],"variableName":"ranchers"}
var target_path_src_components_Navbar_jsx_import_Ranchers_arguments_subsets_latin_weight_400_variableName_ranchers_ = __webpack_require__(5920);
var target_path_src_components_Navbar_jsx_import_Ranchers_arguments_subsets_latin_weight_400_variableName_ranchers_default = /*#__PURE__*/__webpack_require__.n(target_path_src_components_Navbar_jsx_import_Ranchers_arguments_subsets_latin_weight_400_variableName_ranchers_);
// EXTERNAL MODULE: ./node_modules/next/dist/api/link.js
var api_link = __webpack_require__(7648);
;// CONCATENATED MODULE: ./src/components/Navbar.jsx
/* __next_internal_client_entry_do_not_use__ default auto */ 



const Navbar = (param)=>{
    let { refs } = param;
    const [isMenuOpen, setIsMenuOpen] = (0,react.useState)(false);
    const handleScroll = (ref)=>{
        var _ref_current;
        (_ref_current = ref.current) === null || _ref_current === void 0 ? void 0 : _ref_current.scrollIntoView({
            behavior: "smooth"
        });
        setIsMenuOpen(false); // Close menu after selecting an item
    };
    return /*#__PURE__*/ (0,jsx_runtime.jsxs)("nav", {
        className: "fixed  top-0 left-0 w-full z-50 flex  justify-between mb-10 items-center px-4 py-2  text-white ".concat((target_path_src_components_Navbar_jsx_import_Ranchers_arguments_subsets_latin_weight_400_variableName_ranchers_default()).className),
        style: {
            backgroundColor: "#020a08b5"
        },
        children: [
            /*#__PURE__*/ (0,jsx_runtime.jsx)("button", {
                className: "text-white md:hidden focus:outline-none ".concat((target_path_src_components_Navbar_jsx_import_Ranchers_arguments_subsets_latin_weight_400_variableName_ranchers_default()).className),
                onClick: ()=>setIsMenuOpen(!isMenuOpen),
                children: /*#__PURE__*/ (0,jsx_runtime.jsx)("svg", {
                    xmlns: "http://www.w3.org/2000/svg",
                    className: "h-6 w-6",
                    fill: "none",
                    viewBox: "0 0 24 24",
                    stroke: "currentColor",
                    children: /*#__PURE__*/ (0,jsx_runtime.jsx)("path", {
                        strokeLinecap: "round",
                        strokeLinejoin: "round",
                        strokeWidth: 2,
                        d: "M4 6h16M4 12h16m-7 6h7"
                    })
                })
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                className: "flex items-center justify-end w-full md:w-auto",
                children: /*#__PURE__*/ (0,jsx_runtime.jsx)("img", {
                    src: "images/fp_splash.png",
                    alt: "FP logo",
                    className: "h-10 w-auto object-contain"
                })
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsxs)("ul", {
                className: "".concat(isMenuOpen ? "flex" : "hidden", " flex-col items-start absolute top-full left-0 w-full bg-red-900 md:flex md:flex-row md:relative md:w-auto md:bg-transparent gap-4 sm:gap-6 md:gap-8 text-[20px] tracking-wider font-semibold ").concat((target_path_src_components_Navbar_jsx_import_Ranchers_arguments_subsets_latin_weight_400_variableName_ranchers_default()).className),
                children: [
                    /*#__PURE__*/ (0,jsx_runtime.jsx)("li", {
                        children: /*#__PURE__*/ (0,jsx_runtime.jsx)("button", {
                            onClick: ()=>handleScroll(refs.aboutRef),
                            className: "hover:text-gray-400 transition-colors duration-300",
                            children: "About"
                        })
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsx)("li", {
                        children: /*#__PURE__*/ (0,jsx_runtime.jsx)("button", {
                            onClick: ()=>handleScroll(refs.segmentsRef),
                            className: "hover:text-gray-400 transition-colors duration-300",
                            children: "Segments"
                        })
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsx)("li", {
                        children: /*#__PURE__*/ (0,jsx_runtime.jsx)("button", {
                            onClick: ()=>handleScroll(refs.achievementsRef),
                            className: "hover:text-gray-400 transition-colors duration-300",
                            children: "Achievements"
                        })
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsx)("li", {
                        children: /*#__PURE__*/ (0,jsx_runtime.jsx)("button", {
                            onClick: ()=>handleScroll(refs.testimonialsRef),
                            className: "hover:text-gray-400 transition-colors duration-300",
                            children: "Testimonials"
                        })
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsx)("li", {
                        children: /*#__PURE__*/ (0,jsx_runtime.jsx)("button", {
                            onClick: ()=>handleScroll(refs.galleryRef),
                            className: "hover:text-gray-400 transition-colors duration-300",
                            children: "Gallery"
                        })
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsx)("li", {
                        children: /*#__PURE__*/ (0,jsx_runtime.jsx)("button", {
                            onClick: ()=>handleScroll(refs.sponsorsRef),
                            className: "hover:text-gray-400 transition-colors duration-300",
                            children: "Sponsors"
                        })
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsx)("li", {
                        children: /*#__PURE__*/ (0,jsx_runtime.jsx)("button", {
                            onClick: ()=>handleScroll(refs.footerRef),
                            className: "hover:text-gray-400 transition-colors duration-300",
                            children: "Contact Us"
                        })
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsx)("li", {
                        children: /*#__PURE__*/ (0,jsx_runtime.jsx)(api_link["default"], {
                            href: "/webteam",
                            className: "hover:text-gray-400 transition-colors duration-300",
                            children: "Web Team"
                        })
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ var components_Navbar = (Navbar);

// EXTERNAL MODULE: ./node_modules/react-slick/lib/index.js
var lib = __webpack_require__(6406);
// EXTERNAL MODULE: ./node_modules/framer-motion/dist/es/components/AnimatePresence/index.mjs + 3 modules
var AnimatePresence = __webpack_require__(8614);
// EXTERNAL MODULE: ./node_modules/slick-carousel/slick/slick.css
var slick = __webpack_require__(7425);
// EXTERNAL MODULE: ./node_modules/slick-carousel/slick/slick-theme.css
var slick_theme = __webpack_require__(9608);
;// CONCATENATED MODULE: ./src/components/SpinningWheel.jsx
/* __next_internal_client_entry_do_not_use__ default auto */ 






const SpinningWheel = ()=>{
    const items = Array.from({
        length: 25
    }, (_, i)=>i + 1);
    const [selectedItem, setSelectedItem] = (0,react.useState)(null);
    const [showCarousel, setShowCarousel] = (0,react.useState)(false);
    const [carouselData, setCarouselData] = (0,react.useState)(false);
    const [currentSlide, setCurrentSlide] = (0,react.useState)(0);
    const [isMobile, setIsMobile] = (0,react.useState)(window.innerWidth < 768);
    const [showGif, setShowGif] = (0,react.useState)(false); // State to manage GIF visibility
    const [wheelVisible, setWheelVisible] = (0,react.useState)(true);
    (0,react.useEffect)(()=>{
        const handleResize = ()=>{
            setIsMobile(window.innerWidth < 768);
        };
        window.addEventListener("resize", handleResize);
        return ()=>{
            window.removeEventListener("resize", handleResize);
        };
    }, []);
    const selectItem = (index)=>{
        setSelectedItem(index);
        // Set carousel data based on the selected item
        setCarouselData(getCarouselDataForItem(items[index]));
        if (items[index] === 25) {
            // If 25 is selected, hide the wheel and show the GIF
            setWheelVisible(false);
            setCarouselData([]);
            setShowCarousel(false);
            setShowGif(true);
        } else {
            setTimeout(()=>{
                setShowCarousel(true);
            }, 4000);
        }
    };
    // const selectItem = (index) => {
    //   setSelectedItem(index);
    //   const spinDuration = 4000; // Set spin duration (in milliseconds)
    //   // If 25 is selected, hide the wheel and show the GIF after the spin
    //   if (items[index] === 25) {
    //     setTimeout(() => {
    //       setWheelVisible(false);
    //       setShowGif(true);
    //     }, spinDuration); // Wait for the spin to complete
    //   } else {
    //     // For other items, show the carousel after the spin
    //     setTimeout(() => {
    //       setCarouselData(getCarouselDataForItem(items[index]));
    //       setShowCarousel(true);
    //     }, spinDuration); // Wait for the spin to complete
    //   }
    // };
    const getCarouselDataForItem = (item)=>{
        // Map of items to their respective sets of images
        const imageSets = {
            1: [
                "/images/FP(GEN)/FP(1).jpg",
                "/images/FP(GEN)/FP(2).jpg",
                "/images/FP(GEN)/FP(3).jpg",
                "/images/FP(GEN)/FP(4).jpg",
                "/images/FP(GEN)/FP(5).jpg",
                "/images/FP(GEN)/FP(6).jpg",
                "/images/FP(GEN)/FP(7).jpg",
                "/images/FP(GEN)/FP(8).jpg",
                "/images/FP(GEN)/FP(9).jpg",
                "/images/FP(GEN)/FP(10).jpg"
            ],
            2: [
                "/images/FP(GEN)/FP(1).jpg",
                "/images/FP(GEN)/FP(2).jpg",
                "/images/FP(GEN)/FP(3).jpg",
                "/images/FP(GEN)/FP(4).jpg",
                "/images/FP(GEN)/FP(5).jpg",
                "/images/FP(GEN)/FP(6).jpg",
                "/images/FP(GEN)/FP(7).jpg",
                "/images/FP(GEN)/FP(8).jpg",
                "/images/FP(GEN)/FP(9).jpg",
                "/images/FP(GEN)/FP(10).jpg"
            ],
            3: [
                "/images/FP(GEN)/FP(1).jpg",
                "/images/FP(GEN)/FP(2).jpg",
                "/images/FP(GEN)/FP(3).jpg",
                "/images/FP(GEN)/FP(4).jpg",
                "/images/FP(GEN)/FP(5).jpg",
                "/images/FP(GEN)/FP(6).jpg",
                "/images/FP(GEN)/FP(7).jpg",
                "/images/FP(GEN)/FP(8).jpg",
                "/images/FP(GEN)/FP(9).jpg",
                "/images/FP(GEN)/FP(10).jpg"
            ],
            4: [
                "/images/FP(GEN)/FP(1).jpg",
                "/images/FP(GEN)/FP(2).jpg",
                "/images/FP(GEN)/FP(3).jpg",
                "/images/FP(GEN)/FP(4).jpg",
                "/images/FP(GEN)/FP(5).jpg",
                "/images/FP(GEN)/FP(6).jpg",
                "/images/FP(GEN)/FP(7).jpg",
                "/images/FP(GEN)/FP(8).jpg",
                "/images/FP(GEN)/FP(9).jpg",
                "/images/FP(GEN)/FP(10).jpg"
            ],
            5: [
                "/images/FP(GEN)/FP(1).jpg",
                "/images/FP(GEN)/FP(2).jpg",
                "/images/FP(GEN)/FP(3).jpg",
                "/images/FP(GEN)/FP(4).jpg",
                "/images/FP(GEN)/FP(5).jpg",
                "/images/FP(GEN)/FP(6).jpg",
                "/images/FP(GEN)/FP(7).jpg",
                "/images/FP(GEN)/FP(8).jpg",
                "/images/FP(GEN)/FP(9).jpg",
                "/images/FP(GEN)/FP(10).jpg"
            ],
            6: [
                "/images/FP(GEN)/FP(1).jpg",
                "/images/FP(GEN)/FP(2).jpg",
                "/images/FP(GEN)/FP(3).jpg",
                "/images/FP(GEN)/FP(4).jpg",
                "/images/FP(GEN)/FP(5).jpg",
                "/images/FP(GEN)/FP(6).jpg",
                "/images/FP(GEN)/FP(7).jpg",
                "/images/FP(GEN)/FP(8).jpg",
                "/images/FP(GEN)/FP(9).jpg",
                "/images/FP(GEN)/FP(10).jpg"
            ],
            6: [
                "/images/FP(GEN)/FP(1).jpg",
                "/images/FP(GEN)/FP(2).jpg",
                "/images/FP(GEN)/FP(3).jpg",
                "/images/FP(GEN)/FP(4).jpg",
                "/images/FP(GEN)/FP(5).jpg",
                "/images/FP(GEN)/FP(6).jpg",
                "/images/FP(GEN)/FP(7).jpg",
                "/images/FP(GEN)/FP(8).jpg",
                "/images/FP(GEN)/FP(9).jpg",
                "/images/FP(GEN)/FP(10).jpg"
            ],
            7: [
                "/images/FP(GEN)/FP(1).jpg",
                "/images/FP(GEN)/FP(2).jpg",
                "/images/FP(GEN)/FP(3).jpg",
                "/images/FP(GEN)/FP(4).jpg",
                "/images/FP(GEN)/FP(5).jpg",
                "/images/FP(GEN)/FP(6).jpg",
                "/images/FP(GEN)/FP(7).jpg",
                "/images/FP(GEN)/FP(8).jpg",
                "/images/FP(GEN)/FP(9).jpg",
                "/images/FP(GEN)/FP(10).jpg"
            ],
            8: [
                "/images/FP(GEN)/FP(1).jpg",
                "/images/FP(GEN)/FP(2).jpg",
                "/images/FP(GEN)/FP(3).jpg",
                "/images/FP(GEN)/FP(4).jpg",
                "/images/FP(GEN)/FP(5).jpg",
                "/images/FP(GEN)/FP(6).jpg",
                "/images/FP(GEN)/FP(7).jpg",
                "/images/FP(GEN)/FP(8).jpg",
                "/images/FP(GEN)/FP(9).jpg",
                "/images/FP(GEN)/FP(10).jpg"
            ],
            9: [
                "/images/FP(GEN)/FP(1).jpg",
                "/images/FP(GEN)/FP(2).jpg",
                "/images/FP(GEN)/FP(3).jpg",
                "/images/FP(GEN)/FP(4).jpg",
                "/images/FP(GEN)/FP(5).jpg",
                "/images/FP(GEN)/FP(6).jpg",
                "/images/FP(GEN)/FP(7).jpg",
                "/images/FP(GEN)/FP(8).jpg",
                "/images/FP(GEN)/FP(9).jpg",
                "/images/FP(GEN)/FP(10).jpg"
            ],
            10: [
                "/images/FP(GEN)/FP(1).jpg",
                "/images/FP(GEN)/FP(2).jpg",
                "/images/FP(GEN)/FP(3).jpg",
                "/images/FP(GEN)/FP(4).jpg",
                "/images/FP(GEN)/FP(5).jpg",
                "/images/FP(GEN)/FP(6).jpg",
                "/images/FP(GEN)/FP(7).jpg",
                "/images/FP(GEN)/FP(8).jpg",
                "/images/FP(GEN)/FP(9).jpg",
                "/images/FP(GEN)/FP(10).jpg"
            ],
            11: [
                "/images/X1/X1(1).jpg",
                "/images/X1/X1(2).jpg",
                "/images/X1/X1(3).jpg",
                "/images/X1/X1(4).jpg",
                "/images/X1/X1(5).jpg"
            ],
            12: [
                "/images/X2/X2(1).jpg",
                "/images/X2/X2(2).jpg",
                "/images/X2/X2(3).jpg"
            ],
            13: [
                "/images/X3/X3(1).jpg",
                "/images/X3/X3(2).jpg",
                "/images/X3/X3(3).jpg",
                "/images/X3/X3(4).jpg",
                "/images/X3/X3(5).jpg",
                "/images/X3/X3(6).jpg",
                "/images/X3/X3(7).jpg",
                "/images/X3/X3(8).jpg",
                "/images/X3/X3(9).jpg"
            ],
            14: [
                "/images/X4/X4(1).jpg",
                "/images/X4/X4(2).jpg",
                "/images/X4/X4(3).jpg"
            ],
            15: [
                "/images/X5/X5(1).jpg",
                "/images/X4/X4(3).jpg",
                "/images/X3/X3(7).jpg",
                "/images/X4/X4(3).jpg"
            ],
            16: [
                "/images/X6/X6(1).jpg",
                "/images/X6/X6(2).jpg",
                "/images/X3/X3(7).jpg",
                "/images/X6/X6(3).jpg",
                "/images/X7/X7(2).jpg"
            ],
            17: [
                "/images/X7/X7(1).jpg",
                "/images/X7/X7(2).jpg",
                "/images/X7/X7(3).jpg",
                "/images/X7/X7(4).jpg",
                "/images/X7/X7(5).jpg",
                // "/images/X7/X7(6).jpg",
                "/images/X7/X7(7).jpg",
                "/images/X7/X7(8).jpg",
                "/images/X7/X7(9).jpg",
                "/images/X7/X7(10).jpg",
                "/images/X7/X7(11).jpg",
                "/images/X7/X7(12).jpg",
                "/images/X7/X7(13).jpg",
                "/images/X7/X7(14).jpg",
                "/images/X7/X7(15).jpg",
                "/images/X7/X7(16).jpg"
            ],
            18: [
                "/images/X8/X8(1).jpg",
                "/images/X8/X8(2).jpg",
                "/images/X8/X8(3).jpg",
                "/images/X8/X8(4).jpg",
                "/images/X8/X8(5).jpg",
                "/images/X8/X8(6).jpg",
                "/images/X8/X8(7).jpg",
                "/images/X8/X8(8).jpg"
            ],
            19: [
                "/images/X9/X9(1).jpg",
                "/images/X9/X9(2).jpg",
                "/images/X9/X9(3).jpg",
                "/images/X9/X9(4).jpg",
                "/images/X9/X9(5).jpg",
                "/images/X9/X9(6).jpg",
                "/images/X9/X9(7).jpg",
                "/images/X9/X9(8).jpg",
                "/images/X9/X9(9).jpg",
                "/images/X9/X9(10).jpg",
                "/images/X9/X9(11).jpg",
                "/images/X9/X9(12).jpg"
            ],
            20: [
                "/images/X10/X10(2).png",
                "/images/X10/X10(3).png",
                "/images/X10/X10(4).png",
                "/images/X10/X10(5).png"
            ],
            21: [
                "/images/21/21(1).png",
                "/images/21/21(2).png",
                "/images/21/21(3).png",
                "/images/21/21(4).png",
                "/images/21/21(5).png",
                "/images/21/21(6).png",
                "/images/21/21(7).png"
            ],
            22: [
                "/images/22/image1.jpg",
                "/images/22/image2.jpg",
                "/images/22/image6.jpg",
                "/images/22/image7.jpg",
                "/images/22/image8.jpg",
                "/images/22/image9.jpg",
                "/images/22/image10.jpg",
                "/images/22/image11.jpg",
                "/images/22/image19.jpg"
            ],
            23: [
                "/images/23/23(1).jpg",
                "/images/23/23(2).jpg",
                "/images/23/23(3).jpg",
                "/images/23/23(4).jpg",
                "/images/23/23(5).jpg",
                "/images/23/23(6).jpg",
                "/images/23/image14.jpg",
                "/images/23/image15.jpg",
                "/images/23/image16.jpg",
                "/images/23/image17.jpg",
                "/images/23/image18.jpg",
                "/images/23/image20.jpg"
            ],
            24: [
                "/images/24/image1.jpg",
                "/images/24/image2.jpg",
                "/images/24/image3.jpg",
                "/images/24/image4.jpg",
                "/images/24/image5.jpg",
                "/images/24/image6.jpg",
                "/images/24/image7.jpg",
                "/images/24/image8.jpg",
                "/images/24/image9.jpg",
                "/images/24/image10.jpg",
                "/images/24/image11.jpg"
            ]
        };
        // Return images for the selected item or fallback to an empty array
        return imageSets[item] || [];
    };
    const getDisplayText = (item)=>{
        // Map items 11-20 to X1, X2, ..., X10
        if (item >= 11 && item <= 20) {
            return "X".concat(item - 10);
        }
        return item; // Return the original number for other items
    };
    const wheelVars = {
        "--nb-item": items.length,
        "--selected-item": selectedItem !== null ? selectedItem : 0
    };
    const spinning = selectedItem !== null ? "spinning" : "";
    const settings = {
        dots: true,
        infinite: true,
        speed: 500,
        slidesToShow: 3,
        slidesToScroll: 1,
        autoplay: true,
        autoplaySpeed: 1000,
        arrows: false,
        beforeChange: (current, next)=>setCurrentSlide(next),
        responsive: [
            {
                breakpoint: 768,
                settings: {
                    slidesToShow: 1,
                    slidesToScroll: 1
                }
            }
        ]
    };
    return /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
        style: {
            paddingTop: "70px"
        },
        children: [
            /*#__PURE__*/ (0,jsx_runtime.jsx)(AnimatePresence/* AnimatePresence */.M, {
                children: wheelVisible && /*#__PURE__*/ (0,jsx_runtime.jsx)(proxy/* motion */.E.div, {
                    className: "wheel-container",
                    initial: {
                        opacity: 1
                    },
                    exit: {
                        opacity: 0,
                        scale: 0.8,
                        transition: {
                            duration: 0.8,
                            ease: "easeInOut"
                        }
                    },
                    onAnimationComplete: ()=>{
                        // Ensure the GIF only appears after the wheel disappears
                        setWheelVisible(false);
                        setShowGif(true);
                    },
                    children: /*#__PURE__*/ (0,jsx_runtime.jsx)(proxy/* motion */.E.div, {
                        className: "wheel ".concat(spinning),
                        style: wheelVars,
                        children: items.map((item, index)=>/*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                                className: "wheel-item",
                                style: {
                                    "--item-nb": index
                                },
                                onClick: ()=>selectItem(index),
                                children: [
                                    getDisplayText(item),
                                    " ◉"
                                ]
                            }, index))
                    })
                })
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                children: /*#__PURE__*/ (0,jsx_runtime.jsx)(AnimatePresence/* AnimatePresence */.M, {
                    children: showCarousel && !showGif && /*#__PURE__*/ (0,jsx_runtime.jsx)(proxy/* motion */.E.div, {
                        initial: {
                            opacity: 0,
                            y: 50
                        },
                        animate: {
                            opacity: 1,
                            y: 0
                        },
                        exit: {
                            opacity: 0,
                            y: -50
                        },
                        transition: {
                            duration: 0.5
                        },
                        className: "carousel-container",
                        children: /*#__PURE__*/ (0,jsx_runtime.jsx)(lib/* default */.Z, {
                            ...settings,
                            children: carouselData.map((imagePath, index)=>/*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                                    className: "carousel-item",
                                    children: /*#__PURE__*/ (0,jsx_runtime.jsx)(proxy/* motion */.E.img, {
                                        src: imagePath,
                                        alt: "Image ".concat(index + 1),
                                        style: {
                                            width: "100%",
                                            height: "200px",
                                            objectFit: "cover"
                                        },
                                        initial: {
                                            opacity: 0,
                                            scale: 0.8
                                        },
                                        animate: {
                                            opacity: isMobile && index === currentSlide ? 1 : isMobile ? 0.7 : index === (currentSlide + 1) % carouselData.length ? 1 : 0.7,
                                            scale: isMobile && index === currentSlide ? 1 : isMobile ? 0.8 : index === (currentSlide + 1) % carouselData.length ? 1 : 0.8
                                        },
                                        transition: {
                                            duration: 0.5
                                        }
                                    })
                                }, index))
                        })
                    })
                })
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsx)(AnimatePresence/* AnimatePresence */.M, {
                children: showGif && /*#__PURE__*/ (0,jsx_runtime.jsx)(proxy/* motion */.E.div, {
                    initial: {
                        opacity: 0
                    },
                    animate: {
                        opacity: 1
                    },
                    exit: {
                        opacity: 0,
                        transition: {
                            duration: 0.5
                        }
                    },
                    className: "gif-container",
                    children: /*#__PURE__*/ (0,jsx_runtime.jsx)(proxy/* motion */.E.img, {
                        src: "/images/COMINGSOON10.gif",
                        alt: "Loading...",
                        style: {
                            width: "100%",
                            height: "auto"
                        },
                        initial: {
                            opacity: 0
                        },
                        animate: {
                            opacity: 1,
                            scale: 1
                        },
                        transition: {
                            duration: 1.5,
                            ease: "easeInOut"
                        }
                    })
                })
            })
        ]
    });
};
/* harmony default export */ var components_SpinningWheel = (SpinningWheel);

// EXTERNAL MODULE: ./node_modules/@next/font/google/target.css?{"path":"src\\components\\Segments.jsx","import":"Ranchers","arguments":[{"subsets":["latin"],"weight":"400"}],"variableName":"ranchers"}
var target_path_src_components_Segments_jsx_import_Ranchers_arguments_subsets_latin_weight_400_variableName_ranchers_ = __webpack_require__(135);
var target_path_src_components_Segments_jsx_import_Ranchers_arguments_subsets_latin_weight_400_variableName_ranchers_default = /*#__PURE__*/__webpack_require__.n(target_path_src_components_Segments_jsx_import_Ranchers_arguments_subsets_latin_weight_400_variableName_ranchers_);
;// CONCATENATED MODULE: ./src/components/Segments.jsx
/* __next_internal_client_entry_do_not_use__ default auto */ 



const segmentsData = [
    {
        title: "TECHNOTRON",
        description: "A hub of technical competitions and challenges.",
        logo: "images/TT1.png"
    },
    {
        title: "KALEIDOSCOPE",
        description: "A blend of creativity and analytical thinking.",
        logo: "images/KALEIDO.png"
    },
    {
        title: "QUEST",
        description: "A thrilling treasure hunt through tech and knowledge.",
        logo: "images/QUEST1.png"
    },
    {
        title: "ROLLING SQUARES",
        description: "Unleash your musical and artistic talents.",
        logo: "images/RS2.png"
    },
    {
        title: "FOOTPRINTS STOCK EXCHANGE",
        description: "Simulate stock trading and investments.",
        logo: "images/fse1.png"
    },
    {
        title: "VIRTUOSITY",
        description: "Engage in a world of virtual gaming and fun.",
        logo: "images/VIRTUO1.png"
    },
    {
        title: "FOOTPRINTS SOCIAL RESPONSIBILITY",
        description: "Promote social responsibility initiatives and projects.",
        logo: "images/FSR1.png"
    },
    {
        title: "SCHITRON",
        description: "Technical events and knowledge-based activities.",
        logo: "images/schitronn.png"
    },
    {
        title: "MASCOT",
        description: "Robotics and automation challenges.",
        logo: "images/mascot1.png"
    }
];
const Segments = ()=>{
    const [activeSegment, setActiveSegment] = (0,react.useState)(null);
    const [visibleIndices, setVisibleIndices] = (0,react.useState)([]);
    const cardRefs = (0,react.useRef)([]);
    (0,react.useEffect)(()=>{
        const observer = new IntersectionObserver((entries)=>{
            entries.forEach((entry)=>{
                const index = Number(entry.target.dataset.index);
                if (entry.isIntersecting) {
                    setVisibleIndices((prev)=>[
                            ...new Set([
                                ...prev,
                                index
                            ])
                        ]);
                }
            });
        }, {
            threshold: 0.15
        });
        cardRefs.current.forEach((card)=>{
            if (card) observer.observe(card);
        });
        return ()=>observer.disconnect();
    }, []);
    const handleCardClick = (index)=>{
        setActiveSegment(activeSegment === index ? null : index); // Toggle card
    };
    return /*#__PURE__*/ (0,jsx_runtime.jsxs)(proxy/* motion */.E.div, {
        initial: {
            opacity: 0,
            y: 50
        },
        animate: {
            opacity: 1,
            y: 0
        },
        transition: {
            duration: 0.8
        },
        className: "segments-section text-white",
        children: [
            /*#__PURE__*/ (0,jsx_runtime.jsx)(proxy/* motion */.E.h2, {
                initial: {
                    opacity: 0,
                    y: -150
                },
                animate: {
                    opacity: 1,
                    y: 0
                },
                transition: {
                    duration: 1
                },
                className: "text-4xl font-bold mb-8 text-center ".concat((target_path_src_components_Segments_jsx_import_Ranchers_arguments_subsets_latin_weight_400_variableName_ranchers_default()).className, " tracking-wide"),
                children: "SEGMENTS"
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                className: "grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-8 max-w-5xl mx-auto",
                children: segmentsData.map((segment, index)=>/*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                        ref: (el)=>cardRefs.current[index] = el,
                        "data-index": index,
                        onClick: ()=>handleCardClick(index),
                        className: "p-4 rounded-lg bg-opacity-85 border cursor-pointer transition-all ease-out duration-1000 relative mx-auto ".concat(visibleIndices.includes(index) ? "opacity-100 translate-y-0" : "opacity-0 translate-y-16"),
                        style: {
                            width: "280px",
                            minHeight: activeSegment === index ? "auto" : "220px",
                            borderColor: "#a84343",
                            borderWidth: "2px",
                            boxShadow: "0 0 5px 1px #a84343"
                        },
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                                className: "flex justify-center mb-4",
                                children: /*#__PURE__*/ (0,jsx_runtime.jsx)("img", {
                                    src: segment.logo,
                                    alt: "".concat(segment.title, " logo"),
                                    className: "w-24 h-24 sm:w-28 sm:h-28 transition-transform duration-300 ease-out hover:scale-90"
                                })
                            }),
                            /*#__PURE__*/ (0,jsx_runtime.jsx)("h3", {
                                className: "text-lg sm:text-xl font-semibold mb-2 text-center",
                                children: segment.title
                            }),
                            activeSegment === index && /*#__PURE__*/ (0,jsx_runtime.jsx)("p", {
                                className: "text-center text-gray-300 mt-2 text-sm sm:text-base",
                                children: segment.description
                            })
                        ]
                    }, index))
            })
        ]
    });
};
/* harmony default export */ var components_Segments = (Segments);

// EXTERNAL MODULE: ./node_modules/@next/font/google/target.css?{"path":"src\\components\\Achievements.jsx","import":"Ranchers","arguments":[{"subsets":["latin"],"weight":"400"}],"variableName":"ranchers"}
var target_path_src_components_Achievements_jsx_import_Ranchers_arguments_subsets_latin_weight_400_variableName_ranchers_ = __webpack_require__(1759);
var target_path_src_components_Achievements_jsx_import_Ranchers_arguments_subsets_latin_weight_400_variableName_ranchers_default = /*#__PURE__*/__webpack_require__.n(target_path_src_components_Achievements_jsx_import_Ranchers_arguments_subsets_latin_weight_400_variableName_ranchers_);
;// CONCATENATED MODULE: ./src/components/Achievements.jsx
/* __next_internal_client_entry_do_not_use__ default auto */ 



const achievementsData = [
    {
        title: "Patronage From UNESCO",
        logo: "/images/Unesco.jpg"
    },
    {
        title: "Make In India & Skill India",
        logo: "/images/makeinIndia.jpg"
    },
    {
        title: "SAYEN & CEE",
        logo: "/images/Sayeen.jpg"
    },
    {
        title: "Appreciation From Former Chief Minister",
        logo: "/images/VijayRupani.jpg"
    },
    {
        title: "Accreditation of G20",
        logo: "/images/G20.jpg"
    },
    {
        title: "Appreciation From Home Minister",
        logo: "/images/HomeMinister.jpg"
    },
    {
        title: "Limca Book Of Record",
        logo: "/images/Limca.jpg"
    },
    {
        title: "Guinness Book of World Record",
        logo: "/images/GBW.jpg"
    },
    {
        title: "Young Contributors",
        logo: "/images/Young.jpg"
    }
];
const Achievements = ()=>{
    const [visibleIndices, setVisibleIndices] = (0,react.useState)([]);
    const achievementRefs = (0,react.useRef)([]);
    (0,react.useEffect)(()=>{
        const observer = new IntersectionObserver((entries)=>{
            entries.forEach((entry)=>{
                const index = Number(entry.target.dataset.index);
                if (entry.isIntersecting) {
                    setVisibleIndices((prev)=>[
                            ...new Set([
                                ...prev,
                                index
                            ])
                        ]);
                }
            });
        }, {
            threshold: 0.15
        });
        achievementRefs.current.forEach((card)=>{
            if (card) observer.observe(card);
        });
        return ()=>observer.disconnect();
    }, []);
    return /*#__PURE__*/ (0,jsx_runtime.jsxs)(proxy/* motion */.E.div, {
        initial: {
            opacity: 0,
            y: 50
        },
        animate: {
            opacity: 1,
            y: 0
        },
        transition: {
            duration: 0.8
        },
        className: "achievements-section text-white",
        children: [
            /*#__PURE__*/ (0,jsx_runtime.jsx)(proxy/* motion */.E.h2, {
                initial: {
                    opacity: 0,
                    y: -150
                },
                animate: {
                    opacity: 1,
                    y: 0
                },
                transition: {
                    duration: 1
                },
                className: "text-4xl font-bold mb-8 mt-8 text-center ".concat((target_path_src_components_Achievements_jsx_import_Ranchers_arguments_subsets_latin_weight_400_variableName_ranchers_default()).className, " tracking-wide"),
                children: "ACHIEVEMENTS"
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                className: "grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-8 max-w-5xl mx-auto",
                children: achievementsData.map((achievement, index)=>/*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                        ref: (el)=>achievementRefs.current[index] = el,
                        "data-index": index,
                        className: "p-4 rounded-lg bg-opacity-85 cursor-pointer transition-all ease-out duration-1000 relative mx-auto ".concat(visibleIndices.includes(index) ? "opacity-100 translate-y-0" : "opacity-0 translate-y-16"),
                        style: {
                            width: "280px",
                            minHeight: "220px"
                        },
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                                className: "relative w-full h-40 mb-4",
                                children: /*#__PURE__*/ (0,jsx_runtime.jsx)("img", {
                                    src: achievement.logo,
                                    alt: "".concat(achievement.title, " logo"),
                                    fill: true,
                                    className: "rounded-lg object-cover"
                                })
                            }),
                            /*#__PURE__*/ (0,jsx_runtime.jsx)("h3", {
                                className: "text-lg sm:text-xl font-semibold mb-2 text-center",
                                children: achievement.title
                            })
                        ]
                    }, index))
            })
        ]
    });
};
/* harmony default export */ var components_Achievements = (Achievements);

// EXTERNAL MODULE: ./node_modules/@next/font/google/target.css?{"path":"src\\components\\Testimonials.jsx","import":"Ranchers","arguments":[{"subsets":["latin"],"weight":"400"}],"variableName":"ranchers"}
var target_path_src_components_Testimonials_jsx_import_Ranchers_arguments_subsets_latin_weight_400_variableName_ranchers_ = __webpack_require__(115);
var target_path_src_components_Testimonials_jsx_import_Ranchers_arguments_subsets_latin_weight_400_variableName_ranchers_default = /*#__PURE__*/__webpack_require__.n(target_path_src_components_Testimonials_jsx_import_Ranchers_arguments_subsets_latin_weight_400_variableName_ranchers_);
;// CONCATENATED MODULE: ./src/components/Testimonials.jsx
/* __next_internal_client_entry_do_not_use__ default auto */ 






const testimonialsData = [
    {
        name: "SANJAY RAVAL SIR",
        title: "Motivational Speaker",
        quote: "The event was truly remarkable; it was inspiring to see the students of this university put together such a well-organized program. The enthusiasm and engagement from the audience were incredible!",
        photo: "https://smsr.in/images/641358FOUNDER-800x800.jpg"
    },
    {
        name: "VIVEK ATRAY SIR",
        title: "ex IAS Officer, TEDx Speaker",
        quote: "I liked the event very much, I am happy that students of this university had organized such a great event and the energy could be seen—the audience was very interactive.",
        photo: "https://pbs.twimg.com/profile_images/1248982406817665028/oHeDYRQs_400x400.jpg"
    },
    {
        name: "ADMIRAL KARAMBIR SINGH",
        title: "Former Chief of Naval Staff",
        quote: "I was truly impressed by the passion and dedication of the students. The organizing team did an outstanding job, and it was a privilege to witness such an incredible event.",
        photo: "/kaleido/karambirsingh.png"
    },
    {
        name: "PETER C. SCHULTZ",
        title: "Co-inventor of the fiber optics",
        quote: "The organizers for these conference, everybody, everyone had been very very friendly and helpful and I found very enthusiastic to work with FootPrints.",
        photo: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRp6HE7-J9PqYZrh-1GKKu5dRhFpZumOpIGrw&s"
    },
    {
        name: "AMOD MALVIYA SIR",
        title: "Co-founder of UDAAN, Ex-CTO at Flipkart",
        quote: "I adored the enthusiasm and the energy the students had. Organizing committee did a fantastic job and really it was an honor to be a part of such a great event.",
        photo: "https://www.emergingmarketsconference.org/_next/image?url=https%3A%2F%2Fapi.emergingmarketsconference.org%2Fuploads%2Fuser%2F1711434953026-amod.jpeg&w=3840&q=75"
    },
    {
        name: "Lt. Gen SATISH DUA",
        title: "Mastermind of URI Surgical Strike",
        quote: "I am thankful to Team Footprints to invite me to such an outstanding event. Everyone's enthusiasm was terrific and the event was organized in such a flawless manner. It has really been an honor and a delight to be here. Jai Hind!",
        photo: "https://static.toiimg.com/thumb/msid-55231152,width-400,resizemode-4/55231152.jpg"
    },
    {
        name: "ABHI & NIYU",
        title: "Youtubers/Content Creators Youth",
        quote: "It was remarkably delightful to be in the auditorium and having a chance to interact with so many people. Our panel was very well moderated by Ajay sir and was a very enjoyable experience. We have one message for all that because of your support, HUME FARAK PADTA HAI!",
        photo: "https://th-i.thgim.com/public/incoming/b884zd/article66199541.ece/alternates/FREE_1200/Abhi%20and%20Niyu1.jpg"
    },
    {
        name: "AMI GANATRA",
        title: "Author of Ramayana Unravalled , Mahabharata Unravalled",
        quote: "It was a delightful and enthralling experience and I surely had a blast! The team escorted me all over the college and showed me around. If I had more time then I would have surely spent it relishing the event.",
        photo: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQZHO-xAB1VWHeXjapJzqHv07Cg3AEcIjRHfQ&s"
    },
    {
        name: "RADHAKRISHN PILLAI SIR",
        title: "Teacher of Chankayaniti | Tedx Speaker",
        quote: "It was an honor to be a part of such a remarkable event. The quality of the questions asked by the students was amazing as well. Organizers were brilliant and for me this is going to be unforgettable for a lifetime. ",
        photo: "https://www.hua.edu/wp-content/uploads/2022/11/Picture1.png"
    },
    {
        name: "Dr. Pawan Aggarwal",
        title: "International Motivational Speaker",
        quote: "Today's generation can do great things, all you need is to think beyond your capacity and stamina! Even the name of this college has a blessing in itself, 'Maharaja Sayajirao Gaekwad.'",
        photo: "https://www.drpawanagrawal.com/assets/images/dr-pawan-agrawal-pic.jpg"
    },
    {
        name: "RAGHAVA RAO",
        title: "CFO Amazon India",
        quote: "It's been a great experience starting from the hospitality and the way the administration arrangements are being made and it was a delight to watch the crowd gathered for the event.",
        photo: "https://www.indiaretailing.com/wp-content/uploads/2019/11/0-2.jpg"
    }
];
const Testimonials = ()=>{
    const settings = {
        dots: true,
        infinite: true,
        speed: 500,
        slidesToShow: 3,
        slidesToScroll: 1,
        autoplay: true,
        autoplaySpeed: 3000,
        responsive: [
            {
                breakpoint: 1024,
                settings: {
                    slidesToShow: 2
                }
            },
            {
                breakpoint: 768,
                settings: {
                    slidesToShow: 1
                }
            }
        ]
    };
    return /*#__PURE__*/ (0,jsx_runtime.jsxs)(proxy/* motion */.E.div, {
        className: "testimonials-section py-16 px-8 text-white",
        initial: "hidden",
        whileInView: "visible",
        viewport: {
            once: false,
            amount: 0.1
        },
        children: [
            /*#__PURE__*/ (0,jsx_runtime.jsx)(proxy/* motion */.E.h2, {
                className: "text-4xl font-bold mb-8 text-center ".concat((target_path_src_components_Testimonials_jsx_import_Ranchers_arguments_subsets_latin_weight_400_variableName_ranchers_default()).className, " tracking-wide"),
                children: "TESTIMONIALS"
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsx)(lib/* default */.Z, {
                ...settings,
                className: "max-w-6xl mx-auto",
                children: testimonialsData.map((testimonial, index)=>/*#__PURE__*/ (0,jsx_runtime.jsx)(proxy/* motion */.E.div, {
                        className: "px-4",
                        initial: "hidden",
                        whileInView: "visible",
                        viewport: {
                            once: false,
                            amount: 0.2
                        },
                        children: /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                            className: "p-6 rounded-lg bg-opacity-85 cursor-pointer transition-all duration-300 relative transform hover:shadow-lg hover:scale-100 flex flex-col justify-between sm:min-h-[400px] sm:max-h-[400px] lg:min-h-[500px] lg:max-h-[500px]",
                            style: {
                                backgroundColor: "rgba(151, 25, 25, 0.2)",
                                boxShadow: "0 5px 8px rgba(0, 0, 0, 0.5)"
                            },
                            children: [
                                /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                                    className: "flex-grow overflow-scroll hide-scrollbar",
                                    children: /*#__PURE__*/ (0,jsx_runtime.jsx)("p", {
                                        className: "italic text-sm sm:text-base lg:text-lg mb-4 text-center",
                                        style: {
                                            maxHeight: "none",
                                            overflow: "visible"
                                        },
                                        children: '"'.concat(testimonial.quote, '"')
                                    })
                                }),
                                /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                                    className: "flex items-center justify-center mb-4",
                                    children: /*#__PURE__*/ (0,jsx_runtime.jsx)("img", {
                                        src: testimonial.photo,
                                        alt: testimonial.name,
                                        className: "w-24 h-24 rounded-full object-cover"
                                    })
                                }),
                                /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                                    className: "flex flex-col items-center justify-center",
                                    children: [
                                        /*#__PURE__*/ (0,jsx_runtime.jsx)("h3", {
                                            className: "font-semibold text-xl sm:text-2xl lg:text-3xl text-center overflow-scroll text-nowrap hide-scrollbar",
                                            style: {
                                                maxWidth: "100%"
                                            },
                                            children: testimonial.name
                                        }),
                                        /*#__PURE__*/ (0,jsx_runtime.jsx)("p", {
                                            className: "text-sm sm:text-base lg:text-lg text-gray-400 text-center overflow-scroll text-nowrap hide-scrollbar",
                                            style: {
                                                maxWidth: "100%"
                                            },
                                            children: testimonial.title
                                        })
                                    ]
                                })
                            ]
                        })
                    }, index))
            })
        ]
    });
};
/* harmony default export */ var components_Testimonials = (Testimonials);

// EXTERNAL MODULE: ./node_modules/@next/font/google/target.css?{"path":"src\\components\\Gallery.jsx","import":"Ranchers","arguments":[{"subsets":["latin"],"weight":"400"}],"variableName":"ranchers"}
var target_path_src_components_Gallery_jsx_import_Ranchers_arguments_subsets_latin_weight_400_variableName_ranchers_ = __webpack_require__(4194);
var target_path_src_components_Gallery_jsx_import_Ranchers_arguments_subsets_latin_weight_400_variableName_ranchers_default = /*#__PURE__*/__webpack_require__.n(target_path_src_components_Gallery_jsx_import_Ranchers_arguments_subsets_latin_weight_400_variableName_ranchers_);
;// CONCATENATED MODULE: ./src/components/Gallery.jsx
// components/Gallery.js
/* __next_internal_client_entry_do_not_use__ default auto */ 





const galleryImages = [
    {
        src: "/images/244/image1.jpg",
        alt: "Image 1"
    },
    {
        src: "/images/244/image2.jpg",
        alt: "Image 2"
    },
    {
        src: "/images/244/image3.jpg",
        alt: "Image 3"
    },
    {
        src: "/images/244/image6.jpg",
        alt: "Image 3"
    },
    {
        src: "/images/244/image5.jpg",
        alt: "Image 3"
    }
];
const Gallery = ()=>{
    const settings = {
        dots: false,
        infinite: true,
        speed: 1000,
        slidesToShow: 3,
        slidesToScroll: 1,
        autoplay: true,
        autoplaySpeed: 2000,
        responsive: [
            {
                breakpoint: 1024,
                settings: {
                    slidesToShow: 2
                }
            },
            {
                breakpoint: 768,
                settings: {
                    slidesToShow: 1
                }
            }
        ]
    };
    return /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
        className: "gallery-section  py-16 px-8 text-white text-center",
        children: [
            /*#__PURE__*/ (0,jsx_runtime.jsx)("h2", {
                className: "text-4xl font-bold mb-6 ".concat((target_path_src_components_Gallery_jsx_import_Ranchers_arguments_subsets_latin_weight_400_variableName_ranchers_default()).className, " tracking-wide"),
                children: "GALLERY"
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsx)(lib/* default */.Z, {
                ...settings,
                className: "max-w-5xl mx-auto",
                children: galleryImages.map((image, index)=>/*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                        className: "px-4",
                        children: /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                            className: "relative overflow-hidden rounded-lg shadow-lg",
                            children: /*#__PURE__*/ (0,jsx_runtime.jsx)("img", {
                                src: image.src,
                                alt: image.alt,
                                className: "w-full h-64 object-cover transition-transform duration-500 hover:scale-105"
                            })
                        })
                    }, index))
            })
        ]
    });
};
/* harmony default export */ var components_Gallery = (Gallery);

// EXTERNAL MODULE: ./node_modules/@next/font/google/target.css?{"path":"src\\components\\VideosSection.jsx","import":"Ranchers","arguments":[{"subsets":["latin"],"weight":"400"}],"variableName":"ranchers"}
var target_path_src_components_VideosSection_jsx_import_Ranchers_arguments_subsets_latin_weight_400_variableName_ranchers_ = __webpack_require__(4724);
var target_path_src_components_VideosSection_jsx_import_Ranchers_arguments_subsets_latin_weight_400_variableName_ranchers_default = /*#__PURE__*/__webpack_require__.n(target_path_src_components_VideosSection_jsx_import_Ranchers_arguments_subsets_latin_weight_400_variableName_ranchers_);
// EXTERNAL MODULE: ./node_modules/react-intersection-observer/dist/index.mjs
var dist = __webpack_require__(8819);
;// CONCATENATED MODULE: ./src/components/VideosSection.jsx
/* __next_internal_client_entry_do_not_use__ default auto */ 



const videoLinks = [
    {
        id: "V5ROgRVso90?si=9vPShkQzlMgTkN9j",
        title: "Kaleidoscope Launch Video"
    },
    // {
    //   id: "-8waHD5yGQE?si=yPKlwCxl8uJbjaNM",
    //   title: "Footprints'24 Official AfterMovie",
    // },
    {
        id: "PS85aJvTNKM?si=8jgyTRJkf4RSTI8G",
        title: "Aditya Gadhvi"
    },
    // { id: "4TER0lVOsNg?si=Wk9UIQ4GDxILW_Fw", title: "Footprints'24 Official Teaser" },
    {
        id: "-8waHD5yGQE?si=yPKlwCxl8uJbjaNM",
        title: "Footprints'24 Official AfterMovie"
    },
    {
        id: "nw49b7oyOqM?si=_bpyxYWcUJL4iiG",
        title: "tunein tuesday"
    }
];
const VideosSection = ()=>{
    return /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
        className: "videos-section py-8 sm:py-16 px-4 sm:px-8 text-white text-center",
        children: [
            /*#__PURE__*/ (0,jsx_runtime.jsx)("h2", {
                className: "text-3xl sm:text-4xl font-bold mb-6 ".concat((target_path_src_components_VideosSection_jsx_import_Ranchers_arguments_subsets_latin_weight_400_variableName_ranchers_default()).className, " tracking-wide"),
                children: "VIDEOS"
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                className: "flex flex-col sm:flex-row sm:flex-wrap justify-center items-center gap-4 sm:gap-6 max-w-6xl mx-auto",
                children: videoLinks.map((video, index)=>/*#__PURE__*/ (0,jsx_runtime.jsx)(VideoCard, {
                        video: video,
                        index: index,
                        className: "\n              w-full sm:w-[calc(50%-1.5rem)]\n              ".concat(index === 2 ? "sm:mx-auto" : "", "\n            ")
                    }, index))
            })
        ]
    });
};
const VideoCard = (param)=>{
    let { video, index, className = "" } = param;
    const { ref, inView } = (0,dist/* useInView */.YD)({
        threshold: 0.1,
        triggerOnce: false
    });
    // Determine animation direction based on the index
    const direction = index % 2 === 0 ? "-translate-x-full" : "translate-x-full";
    return /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
        ref: ref,
        className: "\n        transition-all duration-700 transform p-2\n        ".concat(inView ? "translate-x-0 opacity-100" : "".concat(direction, " opacity-0"), "\n        ").concat(className, "\n        sm:translate-x-0  // Disable translate on small screens\n      "),
        children: /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
            className: "relative overflow-hidden rounded-lg shadow-lg",
            children: /*#__PURE__*/ (0,jsx_runtime.jsx)("iframe", {
                src: "https://www.youtube.com/embed/".concat(video.id),
                title: video.title,
                allow: "accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture",
                allowFullScreen: true,
                className: "w-full aspect-video"
            })
        })
    });
};
/* harmony default export */ var components_VideosSection = (VideosSection);

// EXTERNAL MODULE: ./node_modules/@next/font/google/target.css?{"path":"src\\components\\FlashbackFridayVideos.jsx","import":"Ranchers","arguments":[{"subsets":["latin"],"weight":"400"}],"variableName":"ranchers"}
var target_path_src_components_FlashbackFridayVideos_jsx_import_Ranchers_arguments_subsets_latin_weight_400_variableName_ranchers_ = __webpack_require__(6465);
var target_path_src_components_FlashbackFridayVideos_jsx_import_Ranchers_arguments_subsets_latin_weight_400_variableName_ranchers_default = /*#__PURE__*/__webpack_require__.n(target_path_src_components_FlashbackFridayVideos_jsx_import_Ranchers_arguments_subsets_latin_weight_400_variableName_ranchers_);
;// CONCATENATED MODULE: ./src/components/FlashbackFridayVideos.jsx
// components/FlashbackFridayVideos.js
/* __next_internal_client_entry_do_not_use__ default auto */ 



 // Import Framer Motion for animations
const flashbackVideos = [
    {
        imageSrc: "/images/244/image10.jpg",
        title: "Motorcycle Stunt",
        url: "https://www.instagram.com/reel/C-ccggmSc-L/?igsh=bDI0dWtrMmI4eWR0"
    },
    {
        imageSrc: "/images/244/image1.jpg",
        title: "Music Performance",
        url: "https://www.instagram.com/reel/C8v-l-btSm1/?igsh=dXFqbGk4MDFteXpo"
    },
    {
        imageSrc: "/images/fsr11.jpg",
        title: "Charity Event",
        url: "https://www.instagram.com/reel/DBwGQACteqF/?igsh=MThpdW5za3NreXQ0Zg=="
    }
];
const FlashbackFridayVideos = ()=>{
    return /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
        className: "flashback-friday-section py-16 px-8 text-white",
        children: [
            /*#__PURE__*/ (0,jsx_runtime.jsx)(proxy/* motion */.E.h2, {
                className: "text-4xl font-bold mb-6 ".concat((target_path_src_components_FlashbackFridayVideos_jsx_import_Ranchers_arguments_subsets_latin_weight_400_variableName_ranchers_default()).className, " tracking-wide text-center"),
                children: "FLASHBACK FRIDAY VIDEOS"
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                className: "video-grid grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 max-w-5xl mx-auto",
                children: flashbackVideos.map((video, index)=>/*#__PURE__*/ (0,jsx_runtime.jsx)(FlashbackFridayVideos_VideoCard, {
                        video: video
                    }, index))
            })
        ]
    });
};
const FlashbackFridayVideos_VideoCard = (param)=>{
    let { video } = param;
    const { ref, inView } = (0,dist/* useInView */.YD)({
        triggerOnce: true,
        threshold: 0.1
    });
    return /*#__PURE__*/ (0,jsx_runtime.jsx)(proxy/* motion */.E.div, {
        ref: ref,
        className: "transition-transform duration-700 transform ".concat(inView ? "translate-y-0 opacity-100" : "translate-y-10 opacity-0"),
        style: {
            backgroundColor: "rgba(151, 25, 25, 0.2)",
            boxShadow: "0 5px 10px rgba(0, 0, 0, 0.5)"
        },
        whileHover: {
            scale: 1.05,
            boxShadow: "0 10px 20px rgba(0, 0, 0, 0.3)"
        },
        transition: {
            duration: 0.3
        },
        children: /*#__PURE__*/ (0,jsx_runtime.jsx)("a", {
            href: video.url,
            target: "_blank",
            rel: "noopener noreferrer",
            children: /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                className: "relative overflow-hidden rounded-lg shadow-lg",
                children: [
                    /*#__PURE__*/ (0,jsx_runtime.jsx)("img", {
                        src: video.imageSrc,
                        alt: video.title,
                        className: "w-full h-64 object-cover transition-transform duration-300" // Smooth transition for zoom
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                        className: "absolute inset-0 flex items-center justify-center bg-black bg-opacity-40 opacity-0 hover:opacity-100 transition-opacity",
                        children: /*#__PURE__*/ (0,jsx_runtime.jsx)("span", {
                            className: "text-white text-xl font-semibold",
                            children: "View on Instagram"
                        })
                    })
                ]
            })
        })
    });
};
/* harmony default export */ var components_FlashbackFridayVideos = (FlashbackFridayVideos);

;// CONCATENATED MODULE: ./src/components/SponsorsSection.jsx
/* __next_internal_client_entry_do_not_use__ default auto */ 


// Update with actual sponsor names and image paths
const sponsors = [
    {
        name: "Title Sponsor",
        imageSrc: "/images/Images(sponsor)/Matrix ComSec LOGO_Registered Trademark (2).jpg"
    },
    {
        name: "Co-Sponsored By",
        imageSrc: "/images/Images(sponsor)/Layer 1.jpg"
    },
    {
        name: "Associate Sponsor",
        imageSrc: "/images/Images(sponsor)/thldnfmlyf23h6dji26g (1).png"
    },
    {
        name: "Macheanema Sponsor",
        imageSrc: "/images/Images(sponsor)/Axtel.jpg"
    },
    {
        name: "Hydrex & Ballista Sponsor",
        imageSrc: "/images/Images(sponsor)/SEE_.jpg"
    },
    {
        name: "Cybernetics Sponsor",
        imageSrc: "/images/Images(sponsor)/Odyssens.jpg"
    },
    {
        name: "Sanganikee Sponsor",
        imageSrc: "/images/Images(sponsor)/Cosmos.jpg"
    },
    {
        name: "Rasayanam Sponsor",
        imageSrc: "/images/Images(sponsor)/Kats.jpg"
    },
    {
        name: "Rolling Squares Sponsor",
        imageSrc: "/images/Images(sponsor)/Layer 2.jpg"
    },
    {
        name: "Energy Sponsor",
        imageSrc: "/images/Images(sponsor)/Energy.jpg"
    },
    {
        name: "FSE Sponsor",
        imageSrc: "/images/Images(sponsor)/Varni Digital.jpg"
    },
    {
        name: "CAT Sponsor",
        imageSrc: "/images/Images(sponsor)/IMS.jpg"
    },
    {
        name: "Watch partner",
        imageSrc: "/images/Images(sponsor)/Dalson.jpg"
    },
    {
        name: "Gate Sponsor",
        imageSrc: "/images/Images(sponsor)/ACUMEN.jpg"
    },
    {
        name: "Production Partner",
        imageSrc: "/images/Images(sponsor)/Layer 3.jpg"
    },
    {
        name: "hackprints partner",
        imageSrc: "/images/Images(sponsor)/Devfolio.jpg"
    },
    {
        name: "Whatsapp partner",
        imageSrc: "/images/Images(sponsor)/Chikoo.jpg"
    },
    {
        name: "Media Partner",
        imageSrc: "/images/Images(sponsor)/VTM.jpg"
    },
    {
        name: "Optical Partner",
        imageSrc: "/images/Images(sponsor)/Vishnu Opticals.jpg"
    },
    {
        name: "Online Media Partner",
        imageSrc: "/images/Images(sponsor)/YouthBarodian.jpg"
    },
    {
        name: "Online Media Partner",
        imageSrc: "/images/Images(sponsor)/Asgard.jpg"
    },
    {
        name: "Online Media Partner",
        imageSrc: "/images/Images(sponsor)/Vadodara Mirror.jpg"
    },
    {
        name: "Youth partner",
        imageSrc: "/images/Images(sponsor)TPOV.jpg"
    },
    {
        name: "Youth Partner",
        imageSrc: "/images/Images(sponsor)/Yellow-360-Logo-Final.jpg"
    },
    {
        name: "Advertisement Partner",
        imageSrc: "/images/Images(sponsor)/advertising-agency-in-ahmedabad-logo.jpg"
    },
    {
        name: "Flora Partner",
        imageSrc: "/images/Images(sponsor)/malhar florist.jpg"
    },
    {
        name: "Security Partner",
        imageSrc: "/images/Images(sponsor)/Layer 4.jpg"
    },
    {
        name: "Schitron Partner",
        imageSrc: "/images/Images(sponsor)/Robowala.jpg"
    },
    {
        name: "Health Care Partner",
        imageSrc: "/images/Images(sponsor)/Gopinathji.jpg"
    },
    {
        name: "Mascot Sponsor",
        imageSrc: "/images/Images(sponsor)/MIR.jpg"
    },
    {
        name: "Powered By",
        imageSrc: "/images/Images(sponsor)/Prapti.jpg"
    },
    {
        name: "Supported By",
        imageSrc: "/images/Images(sponsor)/Arkel.jpg"
    },
    {
        name: "Hospitality Partner",
        imageSrc: "/imges/Images(sponsor)/Layer 5.jpg"
    },
    {
        name: "Printing Partner",
        imageSrc: "/images/Images(sponsor)/jay printers.jpg"
    },
    {
        name: "Jewellery Partner",
        imageSrc: "/images/Images(sponsor)/Joyalukkas.jpg"
    },
    {
        name: "Cake & Celebration Partner",
        imageSrc: "/images/Images(sponsor)/Goodies Logo.jpg"
    },
    {
        name: "Travel Partner",
        imageSrc: "/images/Images(sponsor)/hta logo.jpg"
    },
    {
        name: "Drone Partner",
        imageSrc: "/images/Images(sponsor)/Robotskull.jpg"
    },
    {
        name: "Paint Partner",
        imageSrc: "/images/Images(sponsor)/omkar.jpg"
    }
];
const SponsorsSection = ()=>{
    const scrollRef = (0,react.useRef)(null);
    (0,react.useEffect)(()=>{
        const scrollContainer = scrollRef.current;
        let scrollAmount = 0;
        const scrollStep = 1;
        const scrollInterval = setInterval(()=>{
            if (scrollContainer) {
                scrollAmount += scrollStep;
                if (scrollAmount >= scrollContainer.scrollWidth / 2) {
                    scrollAmount = 0;
                }
                scrollContainer.scrollLeft = scrollAmount;
            }
        }, 20); // Adjust for scroll speed
        return ()=>clearInterval(scrollInterval);
    }, []);
    return /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
        className: "sponsors-section py-8 text-center",
        children: [
            /*#__PURE__*/ (0,jsx_runtime.jsx)("h2", {
                className: "text-3xl font-bold mb-4",
                style: {
                    color: "white"
                },
                children: "SPONSORS"
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                className: "sponsor-marquee overflow-hidden whitespace-nowrap max-w-5xl mx-auto",
                ref: scrollRef,
                children: /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                    className: "flex items-center gap-8",
                    children: sponsors.concat(sponsors).map((sponsor, index)=>/*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                            className: "flex flex-col items-center min-w-[200px] max-w-[200px]",
                            children: /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                                style: {
                                    backgroundColor: "#ffffff",
                                    borderRadius: "8px",
                                    padding: "10px",
                                    boxShadow: "0 4px 8px rgba(0, 0, 0, 0)",
                                    display: "flex",
                                    flexDirection: "column",
                                    alignItems: "center",
                                    justifyContent: "center",
                                    width: "190px",
                                    height: "190px"
                                },
                                children: [
                                    /*#__PURE__*/ (0,jsx_runtime.jsx)("img", {
                                        src: sponsor.imageSrc,
                                        alt: sponsor.name,
                                        className: "w-32 h-32 object-contain rounded shadow-md",
                                        style: {
                                            maxWidth: "70%",
                                            maxHeight: "70%"
                                        }
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime.jsx)("span", {
                                        className: "text-sm mt-2 text-black",
                                        children: sponsor.name
                                    })
                                ]
                            })
                        }, index))
                })
            })
        ]
    });
};
/* harmony default export */ var components_SponsorsSection = (SponsorsSection);

// EXTERNAL MODULE: ./node_modules/@next/font/google/target.css?{"path":"src\\components\\Footer.jsx","import":"Ranchers","arguments":[{"subsets":["latin"],"weight":"400"}],"variableName":"ranchers"}
var target_path_src_components_Footer_jsx_import_Ranchers_arguments_subsets_latin_weight_400_variableName_ranchers_ = __webpack_require__(6586);
var target_path_src_components_Footer_jsx_import_Ranchers_arguments_subsets_latin_weight_400_variableName_ranchers_default = /*#__PURE__*/__webpack_require__.n(target_path_src_components_Footer_jsx_import_Ranchers_arguments_subsets_latin_weight_400_variableName_ranchers_);
// EXTERNAL MODULE: ./node_modules/@fortawesome/fontawesome-free/css/all.min.css
var all_min = __webpack_require__(3185);
;// CONCATENATED MODULE: ./src/components/Footer.jsx



 // Assuming you're using Next.js for navigation
 // Importing Font Awesome styles
// Forward ref for Footer component
const Footer = /*#__PURE__*/ (0,react.forwardRef)((props, ref)=>{
    return /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
        ref: ref,
        className: "footer py-12 text-white bg-gray-800",
        children: [
            /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                className: "container mx-auto flex flex-col md:flex-row justify-between items-center px-8 space-y-8 md:space-y-0",
                children: [
                    /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                        className: "newsletter text-center md:text-left flex-1",
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime.jsx)("h2", {
                                className: "text-2xl font-bold mb-2 ".concat((target_path_src_components_Footer_jsx_import_Ranchers_arguments_subsets_latin_weight_400_variableName_ranchers_default()).className, " tracking-wider"),
                                children: "NEWSLETTER SIGN-UP"
                            }),
                            /*#__PURE__*/ (0,jsx_runtime.jsx)("p", {
                                className: "mb-4",
                                children: "By subscribing to our mailing list you will always be updated with the latest news from us."
                            }),
                            /*#__PURE__*/ (0,jsx_runtime.jsxs)("form", {
                                className: "flex flex-col md:flex-row items-center",
                                children: [
                                    /*#__PURE__*/ (0,jsx_runtime.jsx)("input", {
                                        type: "email",
                                        placeholder: "Enter Email Address",
                                        className: "bg-gray-700 text-white p-2 rounded-l-md w-full md:w-auto"
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime.jsx)("button", {
                                        className: "bg-blue-500 text-white p-2 rounded-r-md mt-2 md:mt-0 md:ml-2 hover:bg-blue-400",
                                        children: "Subscribe"
                                    })
                                ]
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                        className: "logo flex-1 flex justify-center md:justify-center",
                        children: /*#__PURE__*/ (0,jsx_runtime.jsx)("img", {
                            src: "/images/MSUlogowhite.png" // Placeholder for university logo
                            ,
                            alt: "University Logo",
                            className: "h-24 transition-transform transform hover:scale-110"
                        })
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                        className: "contact-info text-center md:text-left flex-1",
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime.jsx)("h2", {
                                className: "text-2xl font-bold mb-2 ".concat((target_path_src_components_Footer_jsx_import_Ranchers_arguments_subsets_latin_weight_400_variableName_ranchers_default()).className, " tracking-wider"),
                                children: "CONTACT INFO"
                            }),
                            /*#__PURE__*/ (0,jsx_runtime.jsxs)("p", {
                                children: [
                                    "Faculty of Technology & Engineering",
                                    /*#__PURE__*/ (0,jsx_runtime.jsx)("br", {}),
                                    "The Maharaja Sayajirao University of Baroda,",
                                    /*#__PURE__*/ (0,jsx_runtime.jsx)("br", {}),
                                    "Kalabhavan, Vadodara, Gujarat 390001."
                                ]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime.jsxs)("p", {
                                className: "mt-4",
                                children: [
                                    /*#__PURE__*/ (0,jsx_runtime.jsx)("strong", {
                                        children: "Email:"
                                    }),
                                    " info@msufp.in | contact@msufp.in",
                                    /*#__PURE__*/ (0,jsx_runtime.jsx)("br", {}),
                                    /*#__PURE__*/ (0,jsx_runtime.jsx)("strong", {
                                        children: "Phone:"
                                    }),
                                    " +91-93132 37813 | +91-94283 16967"
                                ]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime.jsx)(api_link["default"], {
                                href: "/webteam",
                                children: /*#__PURE__*/ (0,jsx_runtime.jsx)("button", {
                                    className: "bg-transparent border border-blue-500 text-white mt-4 p-2 rounded-md hover:bg-blue-400",
                                    children: "Web Team"
                                })
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                className: "social-media flex justify-center mt-8 space-x-6 text-2xl",
                children: [
                    /*#__PURE__*/ (0,jsx_runtime.jsx)("a", {
                        href: "https://www.instagram.com/footprints.msu?igsh=d3RrcGtlb2FvczFk",
                        target: "_blank",
                        rel: "noopener noreferrer",
                        "aria-label": "Instagram",
                        className: "hover:text-pink-500",
                        children: /*#__PURE__*/ (0,jsx_runtime.jsx)("i", {
                            className: "fab fa-instagram"
                        })
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsx)("a", {
                        href: "https://www.facebook.com/msufp",
                        target: "_blank",
                        rel: "noopener noreferrer",
                        "aria-label": "Facebook",
                        className: "hover:text-blue-500",
                        children: /*#__PURE__*/ (0,jsx_runtime.jsx)("i", {
                            className: "fab fa-facebook"
                        })
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsx)("a", {
                        href: "https://youtube.com/@footprintsmsu?si=gKrsuL31CHE8OLxi",
                        target: "_blank",
                        rel: "noopener noreferrer",
                        "aria-label": "YouTube",
                        className: "hover:text-red-500",
                        children: /*#__PURE__*/ (0,jsx_runtime.jsx)("i", {
                            className: "fab fa-youtube"
                        })
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsx)("a", {
                        href: "https://www.linkedin.com/company/msufp/",
                        target: "_blank",
                        rel: "noopener noreferrer",
                        "aria-label": "LinkedIn",
                        className: "hover:text-blue-700",
                        children: /*#__PURE__*/ (0,jsx_runtime.jsx)("i", {
                            className: "fab fa-linkedin"
                        })
                    })
                ]
            })
        ]
    });
});
// Export Footer
Footer.displayName = "Footer";
/* harmony default export */ var components_Footer = (Footer);

;// CONCATENATED MODULE: ./src/app/page.js
/* __next_internal_client_entry_do_not_use__ default auto */ 













function Home() {
    const [isLoading, setIsLoading] = (0,react.useState)(true);
    // Create refs for each section
    const aboutRef = (0,react.useRef)(null);
    const segmentsRef = (0,react.useRef)(null);
    const achievementsRef = (0,react.useRef)(null);
    const testimonialsRef = (0,react.useRef)(null);
    const galleryRef = (0,react.useRef)(null);
    const sponsorsRef = (0,react.useRef)(null);
    const footerRef = (0,react.useRef)(null);
    const sectionRefs = {
        aboutRef,
        segmentsRef,
        achievementsRef,
        testimonialsRef,
        galleryRef,
        sponsorsRef,
        footerRef
    };
    (0,react.useEffect)(()=>{
        // Simulate a delay for loading
        const timeout = setTimeout(()=>{
            setIsLoading(false);
        }, 2000); // Adjust the delay time as needed
        return ()=>clearTimeout(timeout);
    }, []);
    (0,react.useEffect)(()=>{
        const handlePointerMove = (e)=>{
            const { currentTarget: el, clientX: x, clientY: y } = e;
            const { top: t, left: l, width: w, height: h } = el.getBoundingClientRect();
            el.style.setProperty("--posX", x - l - w / 2);
            el.style.setProperty("--posY", y - t - h / 2);
        };
        document.body.addEventListener("pointermove", handlePointerMove);
        return ()=>{
            document.body.removeEventListener("pointermove", handlePointerMove);
        };
    }, []);
    return /*#__PURE__*/ (0,jsx_runtime.jsx)(jsx_runtime.Fragment, {
        children: isLoading ? /*#__PURE__*/ (0,jsx_runtime.jsx)(components_Loader, {}) : /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
            className: "min-h-screen w-full text-white",
            style: {
                height: "100%",
                minHeight: "100vh",
                width: "100%",
                backgroundImage: "\n              linear-gradient(115deg, rgb(150 0 0), rgb(100 0 0)),\n              radial-gradient(90% 100% at calc(50% + var(--posX, 0) * 1px) calc(0% + var(--posY, 0) * 1px), rgb(200 50 50), rgb(100 0 0)),\n              radial-gradient(100% 100% at calc(80% - var(--posX, 0) * 1px) calc(0% - var(--posY, 0) * 1px), rgb(220 40 40), rgb(120 0 0)),\n              radial-gradient(150% 210% at calc(100% + var(--posX, 0) * 1px) calc(0% + var(--posY, 0) * 1px), rgb(180 20 20), rgb(100 10 10)),\n              radial-gradient(100% 100% at calc(100% - var(--posX, 0) * 1px) calc(30% - var(--posY, 0) * 1px), rgb(240 70 70), rgb(150 20 20)),\n              linear-gradient(60deg, rgb(200 30 30), rgb(150 10 10))",
                backgroundBlendMode: "overlay, overlay, difference, difference, difference, normal",
                overflowX: "hidden"
            },
            children: [
                /*#__PURE__*/ (0,jsx_runtime.jsx)(components_Navbar, {
                    refs: sectionRefs
                }),
                /*#__PURE__*/ (0,jsx_runtime.jsx)(components_SpinningWheel, {}),
                /*#__PURE__*/ (0,jsx_runtime.jsx)("section", {
                    ref: aboutRef,
                    children: /*#__PURE__*/ (0,jsx_runtime.jsx)(components_About, {})
                }),
                /*#__PURE__*/ (0,jsx_runtime.jsx)("section", {
                    ref: segmentsRef,
                    children: /*#__PURE__*/ (0,jsx_runtime.jsx)(components_Segments, {})
                }),
                /*#__PURE__*/ (0,jsx_runtime.jsx)("section", {
                    ref: achievementsRef,
                    children: /*#__PURE__*/ (0,jsx_runtime.jsx)(components_Achievements, {})
                }),
                /*#__PURE__*/ (0,jsx_runtime.jsx)("section", {
                    ref: testimonialsRef,
                    children: /*#__PURE__*/ (0,jsx_runtime.jsx)(components_Testimonials, {})
                }),
                /*#__PURE__*/ (0,jsx_runtime.jsx)("section", {
                    ref: galleryRef,
                    children: /*#__PURE__*/ (0,jsx_runtime.jsx)(components_Gallery, {})
                }),
                /*#__PURE__*/ (0,jsx_runtime.jsx)(components_VideosSection, {}),
                /*#__PURE__*/ (0,jsx_runtime.jsx)(components_FlashbackFridayVideos, {}),
                /*#__PURE__*/ (0,jsx_runtime.jsx)("section", {
                    ref: sponsorsRef,
                    children: /*#__PURE__*/ (0,jsx_runtime.jsx)(components_SponsorsSection, {})
                }),
                /*#__PURE__*/ (0,jsx_runtime.jsx)(components_Footer, {
                    ref: footerRef
                })
            ]
        })
    });
}


/***/ }),

/***/ 1112:
/***/ (function(module) {

// extracted by mini-css-extract-plugin
module.exports = {"loading":"Loader_loading__VZT0F","loading-text":"Loader_loading-text__WWfCR","loading-text-words":"Loader_loading-text-words__b0xY1","bounce":"Loader_bounce__RJCCk"};

/***/ })

},
/******/ function(__webpack_require__) { // webpackRuntimeModules
/******/ var __webpack_exec__ = function(moduleId) { return __webpack_require__(__webpack_require__.s = moduleId); }
/******/ __webpack_require__.O(0, [509,152,50,891,971,117,744], function() { return __webpack_exec__(7729); });
/******/ var __webpack_exports__ = __webpack_require__.O();
/******/ _N_E = __webpack_exports__;
/******/ }
]);
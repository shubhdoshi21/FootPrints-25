self.__BUILD_MANIFEST = {
  "polyfillFiles": [
    "static/chunks/polyfills-42372ed130431b0a.js"
  ],
  "devFiles": [],
  "ampDevFiles": [],
  "lowPriorityFiles": [],
  "rootMainFiles": [
    "static/chunks/webpack-e6d5e7f372dfe8c5.js",
    "static/chunks/fd9d1056-91aa9495991b9c80.js",
    "static/chunks/117-1456bf8bcd1cfcce.js",
    "static/chunks/main-app-3bb7050ec3335c57.js"
  ],
  "pages": {
    "/_app": [
      "static/chunks/webpack-e6d5e7f372dfe8c5.js",
      "static/chunks/framework-f66176bb897dc684.js",
      "static/chunks/main-9872320b470f2577.js",
      "static/chunks/pages/_app-72b849fbd24ac258.js"
    ],
    "/_error": [
      "static/chunks/webpack-e6d5e7f372dfe8c5.js",
      "static/chunks/framework-f66176bb897dc684.js",
      "static/chunks/main-9872320b470f2577.js",
      "static/chunks/pages/_error-7ba65e1336b92748.js"
    ]
  },
  "ampFirstPages": []
};
self.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
,"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js",

];
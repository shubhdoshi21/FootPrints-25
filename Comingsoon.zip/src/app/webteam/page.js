// pages/webteam.js
import React from "react";
import WebTeam from "@/components/WebTeam";
import '@fortawesome/fontawesome-free/css/all.min.css';


const WebTeamPage = () => {
  return (
    <div>
      <WebTeam />
    </div>
  );
};

export default WebTeamPage;
